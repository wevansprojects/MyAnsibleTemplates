#!/bin/bash
printf "This is a test script to check you can use ansible correctly \n"
cd $HOME/Scripts/ansible || return
echo "Checking ansible version and path details"
ansible --version
printf "\n"
printf "Checking ansible inventory and ansible.cfg files are configured correctly \n"
ansible app -m ping

echo "Testing if you can create a folder with ansible"
ansible app -m file -a 'path=$HOME/testdir state=directory'


echo "Testing if you can copy a file with ansible"
ansible app -m copy -a 'src=copyme.txt dest=/home/deploy/copyme.txt'

echo "Testing if ansible can run with sudo permissions"
ansible app -K -m shell -a 'lshw -short'
