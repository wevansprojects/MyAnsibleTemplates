cd $HOME/Scripts/ansible || return
ansible-playbook -K playbooks/cron-tasks/deb-scheduled-tasks.yml