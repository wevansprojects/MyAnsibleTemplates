cd $HOME/Scripts/ansible || return
ansible-playbook -K playbooks/cron-tasks/rhat-scheduled-tasks.yml