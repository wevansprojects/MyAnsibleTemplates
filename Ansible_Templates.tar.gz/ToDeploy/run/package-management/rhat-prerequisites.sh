cd $HOME/Scripts/ansible || return
ansible-playbook -K playbooks/rhat-prerequisites/rhat-prerequisites.yml