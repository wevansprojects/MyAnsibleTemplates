#!/bin/bash
cd $HOME/Scripts/ansible || return
ansible-playbook -K playbooks/install-remove/dnf-install-remove.yml
