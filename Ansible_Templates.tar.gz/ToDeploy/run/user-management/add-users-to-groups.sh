#!/bin/bash
cd $HOME/Scripts/ansible || return
ansible-playbook -K playbooks/user-management/add-to-group/add-to-group.yml
