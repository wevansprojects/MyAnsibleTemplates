#!/bin/bash
cd $HOME/Scripts/ansible || return
ansible-playbook -K playbooks/user-management/create-new-users/create-new-users.yml
