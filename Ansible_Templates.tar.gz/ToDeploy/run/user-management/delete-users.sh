#!/bin/bash
cd $HOME/Scripts/ansible || return
ansible-playbook -K playbooks/user-management/delete-users/delete-users.yml
