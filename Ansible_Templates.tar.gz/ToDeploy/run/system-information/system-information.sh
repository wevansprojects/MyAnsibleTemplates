#!/bin/bash
cd $HOME/Scripts/ansible || return
ansible-playbook -K playbooks/system-information/system-information.yml
