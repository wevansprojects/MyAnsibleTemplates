#!/bin/bash
if [ ! -d "$HOME/Scripts" ]; then
     mkdir "$HOME/Scripts"     
     cp -r "$HOME/Downloads/Ansible_Templates/ToDeploy/" "$HOME/Scripts/ansible/" 
elif [ ! -d "$HOME/Scripts/ansible" ]; then
     cp -r "$HOME/Downloads/Ansible_Templates/ToDeploy/" "$HOME/Scripts/ansible/" 
else 
     cp -r "$HOME/Downloads/Ansible_Templates/ToDeploy/" "$HOME/Scripts/ansible/Templates"   
fi      
