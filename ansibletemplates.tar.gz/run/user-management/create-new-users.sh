#!/bin/bash
cd $HOME/ansible || return
ansible-playbook -K /home/user/ansible/playbooks/user-management/create-new-users/create-new-users.yml
