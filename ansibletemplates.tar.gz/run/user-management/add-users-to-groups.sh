#!/bin/bash
cd $HOME/ansible || return
ansible-playbook -K /home/user/ansible/playbooks/user-management/add-to-group/add-to-group.yml
