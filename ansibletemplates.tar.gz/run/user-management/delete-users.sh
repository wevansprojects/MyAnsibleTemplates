#!/bin/bash
cd $HOME/ansible || return
ansible-playbook -K /home/user/ansible/playbooks/user-management/delete-users/delete-users.yml
