#!/bin/bash
cd $HOME/ansible || return
ansible-playbook -K /home/user/ansible/playbooks/install-remove/dnf-install-remove.yml
