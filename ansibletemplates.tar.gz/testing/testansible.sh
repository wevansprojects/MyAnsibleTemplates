#!/bin/bash
printf "This is a test script to check you can use ansible correctly \n"
homedir="/home/user/ansible"
cd $homedir || return
echo "Checking ansible version and path details"
ansible --version
printf "\n"
printf "Checking ansible inventory and ansible.cfg files are configured correctly \n"
ansible app -m ping

echo "Testing if you can create a folder with ansible"
ansible app -m file -a 'path=/home/user/testdir state=directory'


echo "Testing if you can copy a file with ansible"
ansible app -m copy -a 'src=/home/user/Downloads/copyme.txt dest=/home/user/copyme.txt'

echo "Testing if ansible can run with sudo permissions"
ansible app -K -m shell -a 'lshw -short'
